namespace Empire.Domain.Enums;

public enum PaymentStatus
{
    Unpaid = 1,
    Paid = 2
}

