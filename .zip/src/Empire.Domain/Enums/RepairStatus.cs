namespace Empire.Domain.Enums;

public enum RepairStatus
{
    InProgress = 1,
    Complete = 2,
    Done = 3
}

