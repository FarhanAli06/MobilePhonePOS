namespace Empire.Domain.Enums;

public enum DeviceType
{
    Phone = 1,
    Laptop = 2,
    Part = 3,
    Accessories = 4
}

