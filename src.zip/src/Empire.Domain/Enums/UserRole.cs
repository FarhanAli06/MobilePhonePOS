namespace Empire.Domain.Enums;

public enum UserRole
{
    Manager = 1,
    Technician = 2
}

